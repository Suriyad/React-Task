import React from 'react';
class Word extends React.Component {

    render() {
        return (
            <div>
                <h2>Suriya!!</h2>
            </div>
        )
    }
}
export default Word;