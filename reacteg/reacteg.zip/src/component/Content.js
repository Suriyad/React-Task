import React from 'react';
class Content extends React.Component {
    render() {
        return (
            <div>
                <h3>Paragraph</h3>
                <p>An Array containing the results of calling the provided function for each element in the original array.</p>
            </div>
        )
    }
}
export default Content;