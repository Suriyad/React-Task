import React from 'react';
class Footer extends React.Component {

    render() {
        return (
            <div>
                <label>React Demo done by Suriya</label>
            </div>
        )
    }
}
export default Footer;