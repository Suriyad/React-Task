import React from 'react';
class Header extends React.Component {
    render() {
        return (
            <div>
                <h2>React-Demo</h2>
            </div>
        )
    }
}
export default Header;