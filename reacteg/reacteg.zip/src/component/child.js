import React from 'react';
class Second extends React.Component {
    render() {
        return (
            <h2>{this.props.value}</h2>)
    }
} export default Second 