import React from 'react';
class college extends React.Component {
    render() {
        return (<h2>My department is{this.props.branch}</h2>)


    }
}
export default college;